
def get_full_analysis():
    return "📊 RSI: 45 | 📉 Stochastic: Oversold | 🔎 Volume: Stabil (Simulasi Penuh)"
